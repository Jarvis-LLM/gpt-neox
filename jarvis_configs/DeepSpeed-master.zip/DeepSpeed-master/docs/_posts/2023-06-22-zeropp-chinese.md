---
title: "DeepSpeed ZeRO++：降低4倍网络通信，显著提高大模型及类ChatGPT模型训练效率"
excerpt: ""
link: https://github.com/microsoft/DeepSpeed/blob/master/blogs/zeropp/chinese/README.md
date: 2023-06-22 00:00:00
tags: training ZeRO RLHF Chinese
---
