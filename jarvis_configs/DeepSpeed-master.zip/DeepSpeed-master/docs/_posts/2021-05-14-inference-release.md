---
title: "DeepSpeed: Accelerating large-scale model inference and training via system optimizations and compression"
date:   2021-05-14
link: https://www.microsoft.com/en-us/research/blog/deepspeed-accelerating-large-scale-model-inference-and-training-via-system-optimizations-and-compression/
excerpt: ""
tags: inference English
---
