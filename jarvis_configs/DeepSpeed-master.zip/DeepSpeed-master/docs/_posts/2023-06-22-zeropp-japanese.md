---
title: "DeepSpeed ZeRO++: LLMやチャットモデルの訓練を劇的に高速化 – 通信オーバヘッドを1/4に大幅削減 -"
excerpt: ""
link: https://github.com/microsoft/DeepSpeed/blob/master/blogs/zeropp/japanese/README.md
date: 2023-06-22 00:00:00
tags: training ZeRO RLHF Japanese
---
