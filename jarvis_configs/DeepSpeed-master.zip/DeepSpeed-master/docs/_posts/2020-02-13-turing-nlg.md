---
title: "Turing-NLG: A 17-billion-parameter language model by Microsoft"
date:   2020-02-13
link: https://www.microsoft.com/en-us/research/blog/turing-nlg-a-17-billion-parameter-language-model-by-microsoft/
excerpt: "DeepSpeed was used to train the world's largest language model."
tags: training English
---
