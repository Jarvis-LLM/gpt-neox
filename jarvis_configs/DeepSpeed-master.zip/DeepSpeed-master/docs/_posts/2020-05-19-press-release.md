---
title: "ZeRO-2 & DeepSpeed: Shattering Barriers of Deep Learning Speed & Scale"
excerpt: ""
link: https://www.microsoft.com/en-us/research/blog/ZeRO-2-deepspeed-shattering-barriers-of-deep-learning-speed-scale/
tags: training ZeRO English
date: 2020-05-19 02:00:00
---
