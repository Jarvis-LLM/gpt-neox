---
title: "DeepSpeed Microsoft Research Webinar is now on-demand"
excerpt: ""
tags: presentations English
link: https://note.microsoft.com/MSR-Webinar-DeepSpeed-Registration-On-Demand.html
date: 2020-08-07 00:00:00
---
